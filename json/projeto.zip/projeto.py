import json
from segredo import Senha
import win32com.client as win32

with open(r'C:\Users\rubic\Downloads\nu.json', 'r') as arq:
    arq_json = json.loads(arq.read())

date = arq_json["date"]
date = date.split(" ")
hour = date[1]
date = date[0]
date = date.split("-")
date = f'{date[2]}/{date[1]}/{date[0]}'

name = arq_json["full_name"].split(" ")

email_adress = "rubichavao1@hotmail.com"

email_password = Senha


outlook = win32.Dispatch('outlook.application')

emaill = outlook.CreateItem(0)

emaill.To = 'rubichavao1@gmail.com'
emaill.Subject = 'Confirmação de compra'
emaill.Body = f"""

Ola {name[0].capitalize()}, a sua compra no valor de {arq_json["amount"]} foi confirmada dia {date} as {hour}.
\nInformações completas da compra:
\nID: {arq_json["id"]}                 
\nCPF: {arq_json["user_cpf"]}                 
\nNome Completo: {arq_json["full_name"]}                
\nValor: {arq_json["amount"]}                
\nE-mail: {arq_json["e-mail"]}               
\nData: {date}              
\nHora: {hour}             

"""

emaill.Send()

print('fim')
